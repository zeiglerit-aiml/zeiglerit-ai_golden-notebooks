# Zeigler Jupyter Notebook Collection

A consolidated collection of Jupyter notebooks created across the ML/AI engineering work.

## Structure

### 01_ml_lifecycle
- `00_master_ml_lifecycle.ipynb` — master ML lifecycle walkthrough.
- `exploratory_end_to_end_ml_pipeline.ipynb` — exploratory end-to-end ML pipeline.
- `exploratory_end_to_end_ml_pipeline_iphone_compatible.ipynb` — mobile-friendly variant.

### 02_model_factory_and_serving
- `jupyter_model_factory.ipynb` — model factory / multi-model experimentation notebook.
- `langchain_langgraph_model_serving_workflow.ipynb` — LangChain + LangGraph model-serving workflow.

### 03_agentic_and_langgraph
- `langgraph_mlops_intelligence_training.ipynb` — LangGraph-driven MLOps training/intelligence workflow.
- `agentic_multi_model_platform.ipynb` — agentic multi-model platform example.

### 04_training_and_distillation
- `advanced_distillation_notebook.ipynb` — advanced knowledge-distillation workflow.

### 05_aws_ml_workbench
- `aws_native_ml_pipeline_workbench.ipynb` — AWS-native ML pipeline workbench.
- `aws_native_ml_pipeline_workbench_deployable.ipynb` — deployable AWS workbench variant.

### 06_python_learning
- `Python_Focus_Live_Lab.ipynb` — Python-focused live lab and review notebook.

## Notes
- All notebooks were validated as readable Jupyter notebook JSON before packaging.
- Both original and alternate/deployable/mobile variants are retained intentionally.
- This collection is intended as a learning, experimentation, and scaffolding repo rather than a single deployable application.
